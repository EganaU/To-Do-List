var todolist = [];
var ids = [];
var exists = 0;
var displayed = 0;
var displayed2 = 0;
var displayed3 =0;
var displayed4 = 0;
var displayed5 = 0;
var displayed6 =0;
var campo = document.getElementById("camposContainer");
var show = document.getElementById("show");
var campodelete = document.getElementById("infodelete");
var campoedit = document.getElementById("infoedit");
var structure = ""; 
var task;

function mostrarCampos() {
  show.textContent = ""; 
    if(displayed ==0){

    var idInput = document.createElement("input");
    idInput.setAttribute("type", "text");
    idInput.setAttribute("placeholder", "ID");
    idInput.setAttribute("id","idInput");
    campo.appendChild(idInput);

  
    var tituloInput = document.createElement("input");
    tituloInput.setAttribute("type", "text");
    tituloInput.setAttribute("placeholder", "Title");
    tituloInput.setAttribute("id","tituloInput");
    campo.appendChild(tituloInput);
  
    var categoriaInput = document.createElement("input");
    categoriaInput.setAttribute("type", "text");
    categoriaInput.setAttribute("placeholder", "Category");
    categoriaInput.setAttribute("id","categoriaInput");
    campo.appendChild(categoriaInput);
  
    var descripcionInput = document.createElement("input");
    descripcionInput.setAttribute("type", "email");
    descripcionInput.setAttribute("placeholder", "Description");
    descripcionInput.setAttribute("id","descripcionInput");
    campo.appendChild(descripcionInput);

    var botonCrear = document.createElement("button");
    botonCrear.innerText = "Create";
    botonCrear.setAttribute("onclick", "crearElemento()");
    campo.appendChild(botonCrear);

    displayed =1;
    }else{
      campo.textContent = "";
      displayed = 0;
    }
  }

  function crearElemento() {
    exists = 0;
    var id = document.getElementById("idInput").value;
    for(let j = 0;j<ids.length;j++){
      if(id==ids[j]){
        exists = 1;
        break;
      }
    }
    if(exists == 0){
    ids.push(id);
    var titulo = document.getElementById("tituloInput").value;
    var categoria = document.getElementById("categoriaInput").value;
    var descripcion = document.getElementById("descripcionInput").value;
    if(id ==""||titulo == ""||categoria==""||descripcion==""){
      show.textContent="There are empty fields..."
    }else{
      var todo = {
          id : id,
          title : titulo,
          category : categoria,
          description : descripcion    
      };
     todolist.push(todo);
     campo.textContent = "";
     displayed = 0;
     show.textContent = "Task added succesfully!"
    }
  }else{
    show.textContent = "ID already in use..."
  }
  }

  function mostrarLista() {
    show.textContent = "";
    var espacio = document.getElementById("elementArea");
    
    if (todolist.length === 0) {
      var msjvacio = document.createElement("Label");
      msjvacio.textContent = "No tasks in your list...";
      if (displayed2 === 0) {
        espacio.appendChild(msjvacio);
        displayed2 = 1;
      } else {
        espacio.textContent = "";
        displayed2 = 0;
      }
    } else {
      if (displayed3 === 0) {
        for (let i = 0; i < todolist.length; i++) {
          var display = document.createElement("Label");
          display.innerHTML = "<b>ID:</b> " + todolist[i].id + "<br>" +
                              "<b>Title:</b> " + todolist[i].title + "<br>" +
                              "<b>Category:</b> " + todolist[i].category + "<br>" +
                              "<b>Description:</b> " + todolist[i].description + "<br><br>";
          espacio.appendChild(display);
        }
        displayed3 = 1;
      } else {
        espacio.textContent = "";
        displayed3 = 0;
      }
    }
  }

  function idtodelete(){
    if(displayed4==0){
    var idtodelete = document.createElement("input");
    idtodelete.setAttribute("type", "text");
    idtodelete.setAttribute("placeholder", "ID");
    idtodelete.setAttribute("id","idtodelete");
    campodelete.appendChild(idtodelete);
    
    var botonEliminar = document.createElement("button");
    botonEliminar.innerText = "Delete";
    botonEliminar.setAttribute("onclick", "eliminar()");
    campodelete.appendChild(botonEliminar);
    displayed4 = 1;
    }else{
      campodelete.textContent = "";
      displayed4 =0;
    }
  }

  function eliminar(){
    var found;
    var id = document.getElementById("idtodelete").value;
    for(let i =0;i<todolist.length;i++){
      if(todolist[i].id==id){
        found = todolist[i];
      }
    }
    var index = todolist.indexOf(found);
    campodelete.textContent = index;
    if(index==-1){
      campodelete.textContent = "ID was not found..."
    }else{
      todolist.splice(index,1);
      campodelete.textContent = "Task deleted succesfully!"
      mostrarLista();
    }
  }

  function idtoedit(){
    if(displayed5==0){
      var idtoedit = document.createElement("input");
      idtoedit.setAttribute("type", "text");
      idtoedit.setAttribute("placeholder", "ID");
      idtoedit.setAttribute("id","idtoedit");
      campoedit.appendChild(idtoedit);
      
      var botonEditar = document.createElement("button");
      botonEditar.innerText = "Edit";
      botonEditar.setAttribute("onclick", "editar()");
      campoedit.appendChild(botonEditar);
      displayed5 = 1;
      }else{
        campoedit.textContent = "";
        displayed5 =0;
      }
  }

  function editar(){
    var exists =0;
    var idtoedit = document.getElementById("idtoedit").value;
    for(let i =0;i<todolist.length;i++){
      if(todolist[i].id==idtoedit){
        task = todolist[i];
        exists = 1;
        break;
      }
    }
    if(exists ==1){

    infoedit.textContent = ""; 
    if(displayed6 ==0){

    var idInput = document.createElement("input");
    idInput.setAttribute("type", "text");
    idInput.setAttribute("value", task.id);
    idInput.setAttribute("id","idInput");
    infoedit.appendChild(idInput);

  
    var tituloInput = document.createElement("input");
    tituloInput.setAttribute("type", "text");
    tituloInput.setAttribute("value", task.title);
    tituloInput.setAttribute("id","tituloInput");
    infoedit.appendChild(tituloInput);
  
    var categoriaInput = document.createElement("input");
    categoriaInput.setAttribute("type", "text");
    categoriaInput.setAttribute("value", task.category);
    categoriaInput.setAttribute("id","categoriaInput");
    infoedit.appendChild(categoriaInput);
  
    var descripcionInput = document.createElement("input");
    descripcionInput.setAttribute("type", "email");
    descripcionInput.setAttribute("value", task.description);
    descripcionInput.setAttribute("id","descripcionInput");
    infoedit.appendChild(descripcionInput);

    var botonCrear = document.createElement("button");
    botonCrear.innerText = "Save changes";
    botonCrear.setAttribute("onclick", "savechanges()");
    infoedit.appendChild(botonCrear);

    displayed6 =1;
    }else{
      infoedit.textContent = "";
      displayed6 = 0;
    }   
  }
  }

  function savechanges(){
    var idexists =0;
    var index = todolist.indexOf(task);
    var index2 = ids.indexOf(idtoedit);
     var id = document.getElementById("idInput").value;
     for(let j = 0;j<ids.length;j++){
      if(id==ids[j]){
        idexists = 1;
        break;
      }
    }
    if(idexists == 0){
    ids.push(idtoedit);
     var titulo = document.getElementById("tituloInput").value;
     var categoria = document.getElementById("categoriaInput").value;
     var descripcion = document.getElementById("descripcionInput").value;
     if(id =="" ||titulo == ""||categoria==""||descripcion==""){
       infoedit.textContent="There are empty fields..."
     }else{
       var todo = {
           id : id,
           title : titulo,
           category : categoria,
           description : descripcion    
       };
      todolist.splice(index,1);
      ids.splice(index2,1);
      todolist.push(todo);
      campo.textContent = "";
      displayed = 0;
      infoedit.textContent = "Changes saved succesfully!"
     }
    }else{
      infoedit.textContent = "ID already in use...";
    }
     mostrarLista();
    
  }